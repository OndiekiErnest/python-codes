from tkinter import *
from tkinter import filedialog
from pdf2image import convert_from_path, convert_from_bytes
from PIL import Image, ImageTk
from pytesseract import pytesseract
import xlsxwriter

from pdf2image.exceptions import (
    PDFInfoNotInstalledError,
    PDFPageCountError,
    PDFSyntaxError
)

# CHANGE THIS TO MATCH THE DIRECTORY WHERE TESSERACT WAS INSTALLED
path_to_tesseract = r'C:\Program Files\Tesseract-OCR\tesseract.exe'



class Selection:
    def __init__(self, number):
        self.rect = canvas.create_rectangle(0, 0, 0, 0,
                                            dash=(2,2), fill='', outline='black')
        
        self.col = ''

        self.lbl = Label(ui, text = "Select data column")
        self.text = StringVar()
        self.text.trace('w', self.textChange)
        self.entry = Entry(ui, textvariable = self.text)
        self.lbl.pack(pady = (10, 0))
        self.entry.pack(pady = (0, 0))
        self.btn = Button(ui, text="Remove selection " + str(number), command=self.remove)
        self.btn.pack(pady = (0, 5))
        
        
    def changeNumber(self, number):
        self.btn['text'] = "Remove selection " + str(number)
        
    def remove(self):
        self.btn.pack_forget()
        self.entry.pack_forget()
        self.lbl.pack_forget()
        canvas.delete(self.rect)
        selections.remove(self)
        for i in range(len(selections)):
            selections[i].changeNumber(i + 1)

    def textChange(self, *args):
        self.col = self.text.get()
        print(self.col)

    
images = []
selections = []

startingRow = 1

topx, topy, botx, boty = 0, 0, 0, 0
rect_id = None

output = ""

def get_mouse_posn(event):
    global topy, topx
    topx, topy = event.x, event.y

def update_sel_rect(event):
    global rect_id
    global topy, topx, botx, boty

    botx, boty = event.x, event.y
    
    canvas.coords(rect_id, topx, topy, botx, boty)  # Update selection rect.
    print(canvas.coords(rect_id))

def newSelection():
    global rect_id
    global selections
    
    selections.append(Selection(len(selections) + 1))
    
    #selections.append(canvas.create_rectangle(topx, topy, topx, topy,
    #                                      dash=(2,2), fill='', outline='black'))
    
    rect_id = selections[len(selections) - 1].rect
    
def cutImage():
    global rect_id
    global worksheet
    global workbook
    global images
    global selections
    global startingRow
    global output
    
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet()

    for i in range(len(selections)):
        for j in range(len(images)):
            bounds = canvas.coords(selections[i].rect)
            croppedImage = images[j][0].crop((bounds[0], bounds[1], bounds[2], bounds[3]))
            text = pytesseract.image_to_string(croppedImage)
            print(text)
            worksheet.write(selections[i].col + str(startingRow + j), text.strip())
    workbook.close()
    print("done")
    
    
def fileSelector():
    global filepaths
    global originalFilepaths
    global images
    
    # define the type of files that are allowed
    filetypes = (
        ('All files', '*.*'),
        ('images', '*.jpg'),
        ('images', '*.png')
    )
    # create an open files window
    filenames = filedialog.askopenfilenames(
        title='Open files',
        initialdir='./',
        filetypes=filetypes
    ) 
    
    print(filenames)
    
    for i in range(len(filenames)):
        images.append(convert_from_path(filenames[i]))
    print(images)


    size = images[0][0].size

    maxSize = 800

    if size[0] > size[1]:
        ratio = size[1] / size[0]
        for i in range(len(images)):
            images[i][0] = images[i][0].resize((maxSize, int(maxSize * ratio)))
    else:
        ratio = size[0] / size[1]
        for i in range(len(images)):
            images[i][0] = images[i][0].resize((int(maxSize * ratio), maxSize))

    test = ImageTk.PhotoImage(images[0][0])
    canvas.img = test # Keep reference in case this code is put into a function.
    canvas.create_image(0, 0, image=test, anchor=NW)
    canvas.configure(width = test.width(), height = test.height())

    startingRowLbl = Label(ui, text="Starting Row")
    startingRowLbl.pack(side = TOP, padx = 5, pady = (5, 0))

    startingRowText = StringVar()
    startingRowText.trace('w', changeStartingRow)
    startingRowInput = Entry(ui, textvariable=startingRowText)
    startingRowInput.pack(side = TOP, padx = 5, pady = (0, 5))

def selectOutput():
    global output

    filetypes = (
        ('All files', '*.*'),
        ('Document', '*.xlsx')
    )
    # create an open files window
    output = filedialog.askopenfilenames(
        title='Open files',
        initialdir='./',
        filetypes=filetypes
    )

    output = output[0]


def changeStartingRow(*args):
    global startingRow
    global startingRowText

    startingRow = int(startingRowText.get())
    print(startingRow)

gui = Tk()

display = Frame(gui)
display.pack(side=LEFT)

ui = Frame(gui)
ui.pack(side=LEFT)



pytesseract.tesseract_cmd = path_to_tesseract

canvas = Canvas(display,width = 0, height = 0,
                borderwidth=0, highlightthickness=0)
canvas.pack(side = LEFT, expand=True)

# Create selection rectangle (invisible since corner points are equal).
rect_id = canvas.create_rectangle(topx, topy, topx, topy,
                                  dash=(2,2), fill='', outline='black')

canvas.bind('<Button-1>', get_mouse_posn)
canvas.bind('<B1-Motion>', update_sel_rect)


selectBtn = Button(ui, command=fileSelector, text="Select files")
selectBtn.pack(side=TOP, padx = 5, pady = 5)

outputBtn = Button(ui, command = selectOutput, text="Select output file")
outputBtn.pack(side=TOP, padx = 5, pady = 5)

selectionBtn = Button(ui, command=newSelection, text="New selection")
selectionBtn.pack(side=TOP, padx = 5, pady = 5)

testBtn = Button(ui, command=cutImage, text = "Confirm")
testBtn.pack(side = BOTTOM, padx = 5, pady = 10)



gui.mainloop()