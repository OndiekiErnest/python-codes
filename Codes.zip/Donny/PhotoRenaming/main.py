# tkinter: import widgets to be used in the GUI
from tkinter import (
    Tk, Label, messagebox,
    filedialog, Button, Entry,
    StringVar, Frame,
    BOTTOM, LEFT)
# library to make system calls (renaming files)
import os
# openCV library to recognize QR codes
import cv2


class App():
    """ main application class """

    def __init__(self, root):
        self.root = root
        # list of paths for the selected files
        self.filepaths = []
        # new list of paths for the selected files after they've been renamed (temporary list)
        self.newFilepaths = []
        # list of original file paths, doesn't change after renaming, used to restore the original file names
        self.originalFilepaths = []
        # list of numbers for the lot
        self.lotNumbers = []
        # maximum number of items per lot
        self.maxNumberInLot = 20
        # map widgets
        self.mapWidgets()

    def mapWidgets(self):
        """ create widgets """
        self.root.title('Image Sorter')

        # create 4 frames, each one to store horizontally organized components
        self.frame = Frame(self.root, height=500)
        self.frame.pack()

        self.midFrame = Frame(self.root, height=500)
        self.midFrame.pack()

        self.bottomFrame = Frame(self.root)
        self.bottomFrame.pack(side=BOTTOM)

        self.filesFrame = Frame(self.root)
        self.filesFrame.pack(side=BOTTOM)

        # label for lot numbers
        label = Label(self.frame, text="Lot numbers")

        # create a string variable to get the input values for the lot numbers
        self.textVar = StringVar()
        self.textVar.trace('w', lambda name, index, mode, text=self.textVar: self.storeLotNumbers(self.textVar))
        # create a text input box
        self.inputText = Entry(self.frame, textvariable=self.textVar, width=30)

        # place the label and the input box on the frame
        label.pack(side=LEFT, padx=5, pady=5)
        self.inputText.pack(side=LEFT, padx=5, pady=5)

        # label for numbers in lot
        label2 = Label(self.midFrame, text="Max number in lot")

        # create a string variable to get the input values for the numbers in lot
        self.textVar2 = StringVar()
        self.textVar2.set("20")
        self.textVar2.trace('w', lambda name, index, mode, text=self.textVar2: self.storeNumberInLot(self.textVar2))
        # create a text input box
        self.inputText2 = Entry(self.midFrame, textvariable=self.textVar2, width=25)

        # place the label and the input box on the frame
        label2.pack(side=LEFT, pady=5, padx=5)
        self.inputText2.pack(side=LEFT, pady=5, padx=5)

        # create an place buttons to select, rename and restore files
        selectFilesBtn = Button(self.bottomFrame, text="Select files", command=self.fileSelector)
        selectFilesBtn.pack(pady=5, padx=5, side=LEFT)
        renameFilesBtn = Button(self.bottomFrame, text="Rename files", command=self.rename)
        renameFilesBtn.pack(pady=5, padx=5, side=LEFT)
        restoreFilesBtn = Button(self.bottomFrame, text="Restore files", command=self.restoreFiles)
        restoreFilesBtn.pack(pady=5, padx=5, side=LEFT)

        # create a lable to display the selected folder
        self.filesLabel = Label(self.filesFrame, text="Selected Folder")
        self.filesLabel.pack(pady=5, padx=5, side=LEFT)

    def fileSelector(self):
        """ function to select files """

        # define the type of files that are allowed
        filetypes = (
            ('All files', '.*'),
            ('images', '*.jpg'),
            ('images', '*.png')
        )
        # create and open files window
        filenames = filedialog.askopenfilenames(
            title='Open files',
            initialdir='/',
            filetypes=filetypes
        )

        # if files were selected
        if filenames:
            # store the filepaths obtained through the open files window
            self.filepaths = filenames
            self.originalFilepaths = filenames

            # extract the path of the folder that contains the selected files
            folderPath = os.path.dirname(filenames[0])
            # display it on the correct label
            self.filesLabel.configure(text=folderPath)

    def storeLotNumbers(self, text):
        """ function to store lot numbers, gets called everytime the input changes """

        # extract the string data and split it into its components
        data = text.get()

        # split the string to obtain the values depending on how it was composed
        if "\n" in data:
            lotValues = text.get().split("\n")
        elif "\t" in data:
            lotValues = text.get().split("\t")
        else:
            lotValues = text.get().split(" ")

        # keep track of any error during the storing process
        errorFound = False
        # wipe the lot numbers list before filling it again each time
        self.lotNumbers = []

        # scroll through the extracted values
        for value in lotValues:
            # if the value is valid
            if len(value) != 0:
                # put it in the lot numbers list
                if not (int(value) in self.lotNumbers):
                    self.lotNumbers.append(int(value))
                # if there is a repeated value and the user is about to type a new value
                elif (' ' in data[len(data) - 1] or '\n' in data[len(data) - 1] or '\t' in data[len(data) - 1]):
                    # trigger the error flag
                    errorFound = True
        print(self.lotNumbers)
        # if an error was found (duplicated value)
        if errorFound:
            # notify the user
            messagebox.showerror(title='Error', message='There are multiple lots with the same number')

    def storeNumberInLot(self, text):
        """ function to store the max number in lot, gets called everytime the input changes """

        # store the value put as input
        self.maxNumberInLot = int(text.get().strip())

    def readQRCode(self, filename):
        """ function to read the QR code in an image """
        try:
            # load the image
            img = cv2.imread(filename)
            # initialize the QR code detector
            detector = cv2.QRCodeDetector()
            # try to find a QR code in the image
            data, points, straight_qrcode = detector.detectAndDecode(img)
            # if it didn't find anything, return false
            if points is None or straight_qrcode is None:
                return False
            # otherwise return true
            else:
                return True
        # if an exception was thrown, return false
        except Exception:
            return False

    def rename(self):
        """ function to rename the selected files """

        # if there aren't any files selected, notify the user and return
        if len(self.filepaths) == 0:
            messagebox.showerror(title='Error', message="No files selected")
            return

        # if there aren't enough lot numbers to satisfy the amount of files selected, notify the user and return
        if len(self.lotNumbers) * self.maxNumberInLot < len(self.filepaths):
            messagebox.showerror(title='Error', message="There aren't enough lot numbers to use for all the pictures")
            return

        # if there are duplicate lot numbers, notify the user and return
        for i in range(len(self.lotNumbers) - 1):
            tmp = self.lotNumbers[i]
            for j in range(len(self.lotNumbers) - 1):
                if (i != j) and (tmp == self.lotNumbers[j]):
                    messagebox.showerror(title='Error', message='There are multiple lots with the same number')
                    return

        # initialize the variables for the renaming algorithm
        numberInLot = 1
        lotNumberIndex = 0
        # wipe the new file paths list to later store the new names of the files
        newFilepaths = []

        # for every image in the list of selected files
        for image in self.filepaths:
            # if it contains a QR code
            if self.readQRCode(image):
                print(">>> QR Code", image)
                # skip to the next lot number
                lotNumberIndex += 1
                # if by skipping, there aren't enough lot numbers afterwards, notify the user and return
                if len(self.lotNumbers) - 1 < lotNumberIndex:
                    messagebox.showerror(title='Error', message="There aren't enough lot numbers to use for all the pictures")
                    return

                # restart the number in lot and store the QR code file path to the new file paths
                numberInLot = 1
                newFilepaths.append(image)

            # if the image doesn't contain a QR code
            else:
                # if we reach the end of the lot
                if numberInLot > self.maxNumberInLot:
                    # go to the next lot number
                    lotNumberIndex += 1
                    # if by skipping, there aren't enough lot numbers afterwards, notify the user and return
                    if len(self.lotNumbers) - 1 < lotNumberIndex:
                        messagebox.showerror(title='Error', message="There aren't enough lot numbers to use for all the pictures")
                        return

                    # restart the number in lot
                    numberInLot = 1

                # split the file path into its components
                components = image.split('/')
                # prepare the final string containing the new file name
                finalString = ''
                # extract the file name
                filename = components[len(components) - 1]
                # split it to store the extention (.jpg, .png, etc...)
                filenameComponents = filename.split(".")
                # create the new name with: "lotNumber"_"numberInLot"
                newName = str(self.lotNumbers[lotNumberIndex]) + "_" + str(numberInLot)
                # recompose the string with all its components
                for x in range(len(components) - 1):
                    finalString += components[x] + '/'
                # add the new file name with the previously saved extention
                finalString += (newName + "." + filenameComponents[1])
                # go to the next item in the lot
                numberInLot += 1
                # store the newly created file name
                newFilepaths.append(finalString)

        # actual process of renaming, so far we just prepared the new filenames
        # store the position in the loop
        i = 0
        # flag to check if there was a problem and we need to restore the files
        restore = False

        # scroll through all the files
        for i in range(len(self.filepaths)):
            try:
                # rename the file
                os.rename(self.filepaths[i], newFilepaths[i])
            # if there was an exception
            except Exception:
                # notify the user
                messagebox.showerror(title='Error', message="There is already a file with the same name: " + newFilepaths[i])
                # trigger the restore flag
                restore = True
                # stop the cycle
                break

        # if the restore flag was triggered
        if (restore):
            # scroll through all the files until the flag was triggered
            for j in range(i):
                # rename them back to how they were
                os.rename(newFilepaths[j], self.filepaths[j])
        # otherwise, if everything went well
        else:
            # the old filepath becomes the new filepath
            self.filepaths = newFilepaths

    def restoreFiles(self):
        """function to restore files to their original names"""

        # if there are no selected files, notify the user and return
        if len(self.originalFilepaths) == 0:
            messagebox.showerror(title='Error', message="Nothing to restore")
            return

        # scroll through all the new files and rename them with their original name
        for i in range(len(self.filepaths)):
            os.rename(self.filepaths[i], self.originalFilepaths[i])

        # update the filepath to the old file names
        self.filepaths = self.originalFilepaths


if __name__ == '__main__':
    tk = Tk()
    app = App(tk)
    tk.mainloop()
