__author__ = "Ernesto"
__email__ = "ernestondieki12@gmail.com"
__dated__ = "08-09-22"  # DDMMYY


from PyQt5.QtWidgets import (
    QApplication, QWidget, QPushButton, QMainWindow,
    QLineEdit, QLabel, QHBoxLayout, QVBoxLayout,
    QProgressBar, QFrame, QGroupBox, QScrollArea,
    QTableView, QFileDialog, QMessageBox,
)
from PyQt5.QtCore import (
    Qt, QThreadPool, pyqtSignal,
    QAbstractTableModel,
)
from PyQt5.QtGui import QIcon
from os import rename, scandir
from os.path import (
    dirname, expanduser, normpath,
    splitext, basename, abspath, join)
from cv2 import (imread, QRCodeDetector, resize,
                 cvtColor, COLOR_BGR2GRAY, getRotationMatrix2D,
                 THRESH_OTSU, THRESH_BINARY, warpAffine, threshold,
                 minAreaRect, INTER_CUBIC, BORDER_REPLICATE)
from numpy import where, column_stack
from re import split
import sys


style = """
QWidget {
    font: 18px;
    font-family: Consolas;
}
QLabel#errLabel {
    color: red;
}
QPushButton {
    background-color: #dadada;
    border-radius: 5px;
}
QPushButton:hover {
    background-color: gray;
    border-radius: 5px;
}
QPushButton:disabled {
    color: gray;
}
QPushButton:pressed {
    background-color: #cacaca;
}
QPushButton#stopbtn {
    background-color: #fa7e75;
}
QPushButton#stopbtn:hover {
    background-color: #ed473b;
}
QPushButton#stopbtn:pressed {
    background-color: #fca8a2;
}
QPushButton#stopbtn:disabled {
    color: gray;
    background-color: #edc1be;
}
QMessageBox QPushButton {
    min-width: 60px;
    min-height: 30px;
}
QGroupBox {
    border: 2px solid gray;
    border-radius: 5px;
    margin-top: 4ex;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
}
QLineEdit {
    border-radius: 4px;
    border: 1px solid gray;
}
QLineEdit:focus {
    border: 1px solid gray40;
}
QTableView {
    border-radius: 6px;
}
QProgressBar {
    border: 1px solid gray40;
}
QProgressBar::chunk {
    background-color: gray;
    width: 20px;
}
"""


BASE_DIR = dirname(abspath(__file__))


def r_path(relpath):
    """
        Get absolute path
    """

    base_path = getattr(sys, "_MEIPASS", BASE_DIR)
    return join(base_path, relpath)


def splittxt(txt):
    """ split txt on special characters """
    cleaned = split("[ \n\t,;:-]", txt)
    # remove empty items
    empty_removed = [t for t in cleaned if t]
    # remove duplicates
    return [num for i, num in enumerate(empty_removed) if num not in empty_removed[:i]]


class LotsModel(QAbstractTableModel):
    """ model for holding lot numbers """

    # streamline memory usage
    __slots__ = ("dataList", "header")

    def __init__(self, data, header, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.dataList = [data, ]
        self.header = header

    def rowCount(self, parent):
        return len(self.dataList[0])

    def columnCount(self, parent):
        return len(self.dataList)

    def data(self, index, role):
        if not index.isValid():
            return
        if role == Qt.DisplayRole:
            return self.dataList[index.column()][index.row()]
        if role == Qt.TextAlignmentRole:
            return Qt.AlignRight

    def headerData(self, col, orientation, role):
        try:
            if orientation == Qt.Horizontal and role == Qt.DisplayRole:
                return self.header[col]
        except IndexError:
            pass
        return super().headerData(col, orientation, role)

    def sort(self, col, order):
        """ sort data """
        self.layoutAboutToBeChanged.emit()
        revers = (order == Qt.DescendingOrder)
        self.dataList[0].sort(key=int, reverse=revers)
        self.layoutChanged.emit()


class PasteArea(QFrame):
    """ custom line edit that raises errors """

    __slots__ = ("edit", "label")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # layout for the two widgets
        layout = QVBoxLayout(self)
        # entry for lot numbers
        self.edit = QLineEdit()
        self.edit.setPlaceholderText("Enter lot numbers")

        self.label = QLabel()
        self.label.setObjectName("errLabel")
        self.label.setText("Some characters are not integers!")
        # hide label by default
        self.label.hide()

        layout.addWidget(self.edit)
        layout.addWidget(self.label)
        self.edit.textChanged.connect(self.validate)

    def validate(self, numbers):
        """ raise error msg if numbers isn't an integer """
        string = numbers.strip()
        if string:
            numbers = splittxt(string)
            try:
                [int(number) for number in numbers]
                self.label.hide()
            except ValueError:  # cannot convert to integer
                # raise error text
                self.label.show()
        else:
            self.label.hide()


class Home(QWidget):
    """ main window widgets """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.main_layout = QVBoxLayout(self)

        # lot section
        self.pastearea = PasteArea()

        self.lot_group = QGroupBox("Lot numbers")
        self.lot_layout = QVBoxLayout(self.lot_group)

        self.lot_layout.addWidget(self.pastearea)

        # table for displaying lot numbers
        self.table = QTableView()
        self.table.setShowGrid(False)
        self.table.setSelectionBehavior(QTableView.SelectRows)
        self.table.setEditTriggers(self.table.NoEditTriggers)
        self.table.setSortingEnabled(True)

        self.lot_layout.addWidget(self.table)

        # scroll area for scrollable widgets
        scroll = QScrollArea()
        # remove frame border
        scroll.setFrameStyle(0)
        scroll.setWidget(self.lot_group)
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(400)

        self.main_layout.addWidget(scroll)

        # progress section
        self.progressbar = QProgressBar()
        self.progressbar.setRange(0, 100)
        self.progressbar.setTextVisible(True)
        self.progressbar.setAlignment(Qt.AlignCenter)
        self.progressbar.hide()

        self.main_layout.addWidget(self.progressbar)
        # open folder section
        self.folder_label = QLabel()
        self.folder_label.setAlignment(Qt.AlignCenter)
        self.folder_label.setText("Open folder: --")

        self.main_layout.addWidget(self.folder_label)

        # btns section
        self.btns_layout = QHBoxLayout()
        self.selectbtn = QPushButton("Select folder")
        self.selectbtn.setFixedHeight(40)

        self.renamebtn = QPushButton("Rename files")
        self.renamebtn.setFixedHeight(40)

        self.restorebtn = QPushButton("Restore files")
        self.restorebtn.setFixedHeight(40)

        self.stopbtn = QPushButton("STOP")
        self.stopbtn.setObjectName("stopbtn")
        self.stopbtn.setFixedHeight(40)
        self.stopbtn.setFixedWidth(120)
        self.stopbtn.hide()

        self.btns_layout.addWidget(self.selectbtn, alignment=Qt.AlignTop)
        self.btns_layout.addWidget(self.renamebtn, alignment=Qt.AlignTop)
        self.btns_layout.addWidget(self.restorebtn, alignment=Qt.AlignTop)

        self.main_layout.addLayout(self.btns_layout)
        self.main_layout.addWidget(self.stopbtn, alignment=Qt.AlignCenter)


class App(QMainWindow):
    """ main window class """

    # signals for communication
    rename_thread_started = pyqtSignal()
    restore_thread_started = pyqtSignal()

    rename_thread_progress = pyqtSignal(int)
    restore_thread_progress = pyqtSignal(int)

    rename_thread_done = pyqtSignal()
    restore_thread_done = pyqtSignal()

    error = pyqtSignal(str, str)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.setWindowTitle("Photo Renaming")
        self.setWindowIcon(QIcon(r_path("app.png")))

        # create a threadpool for workers
        self.files_threadpool = QThreadPool()
        # only one thread can be running at a time
        self.files_threadpool.setMaxThreadCount(1)

        # list of paths for the selected files
        self.filepaths = []
        # list of numbers for the lot
        self.lotNumbers = []
        # new-old file names pair used for restoring
        self.new_old = {}
        # previously opened folder
        self.lastopen = expanduser("~\\Pictures")
        self.renaming_stopped = False
        self.num_of_files = 0

        # bind home signals to slots
        self.home_win = Home()
        self.home_win.selectbtn.clicked.connect(self.choose_files)
        self.home_win.renamebtn.clicked.connect(self.thread_renaming)
        self.home_win.restorebtn.clicked.connect(self.start_restoring)
        self.home_win.stopbtn.clicked.connect(self.stop_renaming)
        self.home_win.pastearea.edit.textChanged.connect(self.add_lots)

        # bind app signals to slots/functions
        self.rename_thread_started.connect(self.ren_started)
        self.restore_thread_started.connect(self.res_started)
        self.rename_thread_progress.connect(self.receive_rename_progress)
        self.restore_thread_progress.connect(self.receive_restore_progress)
        self.rename_thread_done.connect(self.ren_done)
        self.restore_thread_done.connect(self.res_done)
        self.error.connect(self.showinfo)

        self.setCentralWidget(self.home_win)

    def stop_renaming(self):
        """ stop renaming process """
        self.renaming_stopped = True

    def add_lots(self, txt):
        """ add lots to the table view after cleaning them """
        self.lotNumbers = splittxt(txt.strip())
        model = LotsModel(self.lotNumbers, ("Lots", ))
        # set data model to the table view
        self.home_win.table.setModel(model)

    def choose_files(self):
        """ choose files to work with """

        folder = QFileDialog.getExistingDirectory(self,
                                                  "Select folder with images - Photo Renaming",
                                                  self.lastopen)
        if not folder:
            return

        # filter only .jpg and .png files
        filenames = [entry.path for entry in scandir(folder) if entry.path.lower().endswith((".png", ".jpg"))]
        # sort based on filenames in ascending order
        filenames.sort(key=basename)
        # if files were selected
        if filenames:
            self.num_of_files = len(filenames)
            # store the filepaths obtained through the open files window
            self.filepaths = filenames

            # extract the path of the folder that contains the selected files
            folderPath = dirname(filenames[0])
            self.lastopen = folderPath
            # display it on label
            self.home_win.folder_label.setText(f"Open folder: {folder} ({self.num_of_files:,} photos)")

    def isQR(self, filename):
        """ function to read the QR code in an image """
        try:
            # load the image
            image = imread(filename)
            # smaller, the better
            scale = 0.2
            width = int(image.shape[1] * scale)
            height = int(image.shape[0] * scale)
            # resize to smaller scale for faster qr detection
            image = resize(image, (width, height))
            # convert to gray
            gray = cvtColor(image, COLOR_BGR2GRAY)
            gray = 255 - gray
            thresh = threshold(gray, 0, 255, THRESH_BINARY + THRESH_OTSU)[1]

            # compute rotated bounding box
            coords = column_stack(where(thresh > 0))
            angle = minAreaRect(coords)[-1]

            if angle < -45:
                angle = -(90 + angle)
            else:
                angle = -angle

            # rotate image to deskew
            (h, w) = image.shape[:2]
            center = (w // 2, h // 2)
            # matrix
            M = getRotationMatrix2D(center, angle, 1.0)
            rotated = warpAffine(image, M, (w, h), flags=INTER_CUBIC, borderMode=BORDER_REPLICATE)
            # initialize the QR code detector
            detector = QRCodeDetector()
            # try to find a QR code in the image
            data, points, straight_qrcode = detector.detectAndDecode(rotated)
            # if it didn't find anything, return false
            if points is None or straight_qrcode is None:
                return False
            # otherwise return true
            else:
                return True
        # if an exception was thrown, return false
        except Exception:
            return False

    def start_renaming(self):
        """ function to rename the selected files """

        # if there aren't any files selected, notify the user and return
        if not self.filepaths:
            self.error.emit("Could not initiate renaming process",
                            "- No folder selected for renaming\n- Or, files have already been renamed")
            self.rename_thread_done.emit()
            return

        if not self.lotNumbers:
            self.error.emit("No lot numbers available for renaming", "Lot numbers are needed to complete the operation")
            self.rename_thread_done.emit()
            return

        # rename started
        self.rename_thread_started.emit()
        progress = 0
        lot_count = 0
        photo_count = 1
        total_files = len(self.filepaths)
        lot_num = self.lotNumbers[0]

        for index, image_path in enumerate(self.filepaths):

            image = normpath(image_path)
            # convert to percentage
            progress = (((index + 1) * 100) / total_files)
            self.rename_thread_progress.emit(int(progress))

            # skip QR code
            if self.isQR(image):
                # increment lot index
                lot_count += 1
                try:
                    # get the next lot number at index `lot_count`
                    lot_num = self.lotNumbers[lot_count]
                except IndexError:
                    self.error.emit("Inadequate lot numbers - Renaming process interrupted",
                                    "Lot numbers are less than the photo groups")
                    self.rename_thread_done.emit()
                    return
                # restart count
                photo_count = 1
                continue
            # rename image
            else:
                src_dir = dirname(image)
                _, ext = splitext(image)
                # new name based on lot number and photo count
                dst = f"{src_dir}\\{lot_num}_{photo_count}{ext}"
                try:
                    rename(image, dst)
                    photo_count += 1
                    # update restoring dict
                    self.new_old[dst] = image
                except Exception:
                    continue
            if self.renaming_stopped:
                self.renaming_stopped = False
                # break out of the loop
                break
        # clear files to avoid errors
        self.filepaths.clear()
        self.rename_thread_done.emit()

    def showinfo(self, txt, info):
        """ show info/error pop-up """
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Information)
        msg.setText(txt)
        msg.setInformativeText(info)
        msg.setWindowTitle("Feedback - Photo Renaming")
        return msg.exec_()

    def enablebtns(self):
        """ enable btns """
        self.home_win.selectbtn.setEnabled(True)
        self.home_win.renamebtn.setEnabled(True)
        self.home_win.restorebtn.setEnabled(True)

    def disablebtns(self):
        """ disable btns """
        self.home_win.selectbtn.setDisabled(True)
        self.home_win.renamebtn.setDisabled(True)
        self.home_win.restorebtn.setDisabled(True)

    def receive_rename_progress(self, progress: int):
        """ receive progress from signal """
        self.home_win.progressbar.setValue(progress)
        self.home_win.progressbar.setFormat(f"Renamed: {progress}% of {self.num_of_files:,} photos")

    def receive_restore_progress(self, progress: int):
        """ receive progress from signal """
        self.home_win.progressbar.setValue(progress)
        self.home_win.progressbar.setFormat(f"Restored: {progress}% of {self.num_of_files:,} photos")

    def ren_started(self):
        """ do the following before renaming """
        self.home_win.stopbtn.show()
        self.home_win.progressbar.show()
        self.disablebtns()

    def ren_done(self):
        """ do the following when done renaming """
        self.home_win.stopbtn.hide()
        self.enablebtns()
        self.home_win.folder_label.setText("Open folder: --")

    def res_started(self):
        """ do the following before restoring """
        self.home_win.progressbar.show()
        self.disablebtns()

    def res_done(self):
        """ do the following when done restoring """
        # self.home_win.progressbar.hide()
        self.enablebtns()

    def thread_renaming(self):
        """ thread `start_renaming` for responsive GUI """
        self.files_threadpool.start(self.start_renaming)

    def thread_restoring(self):
        """ thread `start_restoring` for responsive GUI """
        self.files_threadpool.start(self.start_restoring)

    def start_restoring(self):
        """function to restore files to their original names"""

        # if there are no selected files, notify the user and return
        if not self.new_old:
            self.error.emit("Could not initiate the restoring process",
                            "- No files have been renamed\n- Or, files have already been restored")
            return

        # restoring started
        self.restore_thread_started.emit()
        index = 1
        total_files = len(self.new_old)

        # scroll through all the new files and rename them with their original name
        for src, dst in self.new_old.items():
            progress = ((index * 100) / total_files)
            self.restore_thread_progress.emit(int(progress))
            index += 1
            try:
                rename(src, dst)
            except Exception:
                continue

        # send signal of process done
        self.restore_thread_done.emit()
        # clear the new-old names mapping
        self.new_old.clear()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyleSheet(style)

    main = App()
    main.showMaximized()

    sys.exit(app.exec())
