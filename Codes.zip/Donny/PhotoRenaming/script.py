# tkinter: library used for the graphical user interface (GUI)
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
# library to make system calls (renaming files)
import os
# openCV library to recognize QR codes
import cv2

# list of paths for the selected files
filepaths = []
# new list of paths for the selected files after they've been renamed (temporary list)
newFilepaths = []
# list of original file paths, doesn't change after renaming, used to restore the original file names
originalFilepaths = []
# list of numbers for the lot
lotNumbers = []
# maximum number of items per lot
maxNumberInLot = 20

# function to select files


def fileSelector():
    global filepaths
    global originalFilepaths

    # define the type of files that are allowed
    filetypes = (
        ('All files', '.*'),
        ('images', '*.jpg'),
        ('images', '*.png')
    )
    # create an open files window
    filenames = filedialog.askopenfilenames(
        title='Open files',
        initialdir='/',
        filetypes=filetypes
    )

    # store the filepaths obtained through the open files window
    filepaths = filenames
    originalFilepaths = filenames

    # extract the path of the folder that contains the selected files
    stringComponents = filepaths[len(filepaths) - 1].split('/')

    folderPath = ''

    for i in range(len(stringComponents) - 1):
        folderPath += stringComponents[i] + '/'

    # display it on the correct label
    filesLabel.configure(text=folderPath)

# function to store lot numbers, gets called everytime the input changes


def storeLotNumbers(text):
    global lotNumbers

    # extract the string data and split it into its components
    data = text.get()

    # split the string to obtain the values depending on how it was composed
    if "\n" in data:
        lotValues = text.get().split("\n")
    elif "\t" in data:
        lotValues = text.get().split("\t")
    else:
        lotValues = text.get().split(" ")

    # keep track of any error during the storing process
    errorFound = False
    # wipe the lot numbers list before filling it again each time
    lotNumbers = []

    # scroll through the extracted values
    for value in lotValues:
        # if the vaule is valid
        if len(value) != 0:
            # put it in the lot numbers list
            if not (int(value) in lotNumbers):
                lotNumbers.append(int(value))
            # if there is a repeated value and the user is about to type a new value
            elif (' ' in data[len(data) - 1] or '\n' in data[len(data) - 1] or '\t' in data[len(data) - 1]):
                # trigger the error flag
                errorFound = True
    print(lotNumbers)
    # if an error was found (duplicated value)
    if errorFound:
        # notify the user
        messagebox.showerror(title='Error', message='There are multiple lots with the same number')

# function to store the max number in lot, gets called everytime the input changes


def storeNumberInLot(text):
    global maxNumberInLot
    # store the value put as input
    maxNumberInLot = int(text.get().strip())

# function to read the QR code in an image


def readQRCode(filename):
    try:
        # load the image
        img = cv2.imread(filename)
        # initialize the QR code detector
        detect = cv2.QRCodeDetector()
        # try to find a QR code in the image
        value, points, straight_qrcode = detect.detectAndDecode(img)
        # if it didn't find anything, return false
        if points is None or straight_qrcode is None:
            return(False)
        # otherwise return true
        else:
            return(True)
    # if an exception was thrown, return false
    except:
        return(False)

# function to rename the selected files


def rename():
    global maxNumberInLot
    global filepaths
    global newFilepaths

    # if there aren't any files selected, notify the user and return
    if len(filepaths) == 0:
        messagebox.showerror(title='Error', message="No files selected")
        return

    # if there aren't enough lot numbers to satisfy the amount of files selected, notify the user and return
    if len(lotNumbers) * maxNumberInLot < len(filepaths):
        messagebox.showerror(title='Error', message="There aren't enough lot numbers to use for all the pictures")
        return

    # if there are duplicate lot numbers, notify the user and return
    for i in range(len(lotNumbers) - 1):
        tmp = lotNumbers[i]
        for j in range(len(lotNumbers) - 1):
            if (i != j) and (tmp == lotNumbers[j]):
                messagebox.showerror(title='Error', message='There are multiple lots with the same number')
                return

    # initialize the variables for the renaming algorithm
    numberInLot = 1
    lotNumberIndex = 0
    # wipe the new file paths list to later store the new names of the files
    newFilepaths = []

    # for every image in the list of selected files
    for image in filepaths:
        # if it contains a QR code
        if readQRCode(image):
            # skip to the next lot number
            lotNumberIndex += 1
            # if by skipping, there aren't enough lot numbers afterwards, notify the user and return
            if len(lotNumbers) - 1 < lotNumberIndex:
                messagebox.showerror(title='Error', message="There aren't enough lot numbers to use for all the pictures")
                return

            # restart the number in lot and store the QR code file path to the new file paths
            numberInLot = 1
            newFilepaths.append(image)

        # if the image doesn't contain a QR code
        else:
            # if we reach the end of the lot
            if numberInLot > maxNumberInLot:
                # go to the next lot number
                lotNumberIndex += 1
                # if by skipping, there aren't enough lot numbers afterwards, notify the user and return
                if len(lotNumbers) - 1 < lotNumberIndex:
                    messagebox.showerror(title='Error', message="There aren't enough lot numbers to use for all the pictures")
                    return

                # restart the number in lot
                numberInLot = 1

            # split the file path into its components
            components = image.split('/')
            # prepare the final string containing the new file name
            finalString = ''
            # extract the file name
            filename = components[len(components) - 1]
            # split it to store the extention (.jpg, .png, etc...)
            filenameComponents = filename.split(".")
            # create the new name with: "lotNumber"_"numberInLot"
            newName = str(lotNumbers[lotNumberIndex]) + "_" + str(numberInLot)
            # recompose the string with all its components
            for x in range(len(components) - 1):
                finalString += components[x] + '/'
            # add the new file name with the previously saved extention
            finalString += (newName + "." + filenameComponents[1])
            # go to the next item in the lot
            numberInLot += 1
            # store the newly created file name
            newFilepaths.append(finalString)

    # actual process of renaming, so far we just prepared the new filenames
    # store the position in the loop
    i = 0
    # flag to check if there was a problem and we need to restore the files
    restore = False

    # scroll through all the files
    for i in range(len(filepaths)):
        try:
            # rename the file
            os.rename(filepaths[i], newFilepaths[i])
        # if there was an exception
        except:
            # notify the user
            messagebox.showerror(title='Error', message="There is already a file with the same name: " + newFilepaths[i])
            # trigger the restore flag
            restore = True
            # stop the cycle
            break

    # if the restore flag was triggered
    if (restore):
        # scroll through all the files until the flag was triggered
        for j in range(i):
            # rename them back to how they were
            os.rename(newFilepaths[j], filepaths[j])
    # otherwise, if everything went well
    else:
        # the old filepath becomes the new filepath
        filepaths = newFilepaths

# function to restore files to their original names


def restoreFiles():
    global filepaths
    global originalFilepaths
    # if there are no selected files, notify the user and return
    if len(originalFilepaths) == 0:
        messagebox.showerror(title='Error', message="Nothing to restore")
        return

    # scroll through all the new files and rename them with their original name
    for i in range(len(filepaths)):
        os.rename(filepaths[i], originalFilepaths[i])

    # update the filepath to the old file names
    filepaths = originalFilepaths


# create a window
gui = Tk()
gui.title('Image Sorter')

# create 4 frames, each one to store horizontally organized components
frame = Frame(gui, height=500)
frame.pack()

midFrame = Frame(gui, height=500)
midFrame.pack()

bottomFrame = Frame(gui)
bottomFrame.pack(side=BOTTOM)

filesFrame = Frame(gui)
filesFrame.pack(side=BOTTOM)

# label for lot numbers
label = Label(frame, text="Lot numbers")

# create a string variable to get the input values for the lot numbers
text = StringVar()
text.trace('w', lambda name, index, mode, text=text: storeLotNumbers(text))
# create a text input box
inputText = Entry(frame, textvariable=text, width=30)

# place the label and the input box on the frame
label.pack(side=LEFT, padx=5, pady=5)
inputText.pack(side=LEFT, padx=5, pady=5)


# label for numbers in lot
label2 = Label(midFrame, text="Max number in lot")

# create a string variable to get the input values for the numbers in lot
text2 = StringVar()
text2.set("20")
text2.trace('w', lambda name, index, mode, text=text2: storeNumberInLot(text))
# create a text input box
inputText2 = Entry(midFrame, textvariable=text2, width=25)

# place the label and the input box on the frame
label2.pack(side=LEFT, pady=5, padx=5)
inputText2.pack(side=LEFT, pady=5, padx=5)

# create an place buttons to select, rename and restore files
selectFilesBtn = Button(bottomFrame, text="Select files", command=fileSelector)
selectFilesBtn.pack(pady=5, padx=5, side=LEFT)
renameFilesBtn = Button(bottomFrame, text="Rename files", command=rename)
renameFilesBtn.pack(pady=5, padx=5, side=LEFT)
restoreFilesBtn = Button(bottomFrame, text="Restore files", command=restoreFiles)
restoreFilesBtn.pack(pady=5, padx=5, side=LEFT)

# create a lable to display the selected folder
filesLabel = Label(filesFrame, text="Selected Folder")
filesLabel.pack(pady=5, padx=5, side=LEFT)

# run the GUI
gui.mainloop()
