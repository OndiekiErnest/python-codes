from customs.tables import TableView
from PyQt6.QtWidgets import (
    QWidget,
)


class CategoryWindow(QWidget):
    """ window to display category items """

    __slots__ = ()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.setObjectName("categoryWindow")
