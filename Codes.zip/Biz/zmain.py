from PyQt6.QtWidgets import (
    QApplication, QMainWindow,
)
from home import HomeWindow
import sys


class MainWin(QMainWindow):
    """ main app window """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.setWindowTitle("Management")
        self.setMinimumSize(850, 500)

        self.home = HomeWindow()
        self.setCentralWidget(self.home)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = MainWin()
    win.showMaximized()
    sys.exit(app.exec())
