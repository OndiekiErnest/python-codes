from categorygui import CategoryWindow
from creditgui import CreditWindow
from requestsgui import RequestsWindow
from salesgui import SalesWindow
from customs.buttons import Button
from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout,
    QToolButton,
)
from PyQt6.QtGui import QIcon
from PyQt6.QtCore import QSize


class HomeWindow(QWidget):
    """ window for holding home window widgets """

    __slots__ = ()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setObjectName("homeWindow")

        self.main_layout = QHBoxLayout(self)
        btn = QToolButton()
        btn.setText("ToolButton")
        btn.setIconSize(QSize(100, 100))
        btn.setIcon(QIcon("data\\icon.png"))
        self.main_layout.addWidget(btn)
