from PyQt6.QtWidgets import (
    QTableView,
)


class TableView(QTableView):
    """ custom QTableView widget """

    __slots__ = ()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.setShowGrid(False)
        self.setSelectionBehavior(self.SelectionBehavior.SelectRows)
        self.setSortingEnabled(True)
        self.setAlternatingRowColors(True)
