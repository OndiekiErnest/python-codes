from PyQt6.QtWidgets import (
    QPushButton,
)


class Button(QPushButton):
    """ custom QPushButton widget """

    __slots__ = ()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
