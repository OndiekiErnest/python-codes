# daily expenses
# weekly expenses
# monthly expenses
# annual expenses
# Range expenses
