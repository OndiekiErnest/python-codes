# daily sales
# weekly sales
# monthly sales
# annual sales
# Range sales
