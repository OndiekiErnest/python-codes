import os
import time
from pytube import YouTube
from threading import Thread
from moviepy.video.io.VideoFileClip import VideoFileClip
from moviepy.audio.io.AudioFileClip import AudioFileClip
from moviepy.video.io.ffmpeg_tools import ffmpeg_merge_video_audio


class Base():
    """ YT yt_obj """

    def __init__(self, yt: YouTube):
        self.yt_obj = yt
        self.yt_obj.bypass_age_gate()

        self.stream = None
        self.file_path = ""

    @property
    def thumbnail(self) -> str:
        """ thumbnail link """
        return self.yt_obj.thumbnail_url

    @property
    def filename(self):
        """ name+extension """
        return self.stream.default_filename

    def _download(self, file_dir, prefix=None):
        """ file_dir: folder to save download """
        self.file_path = self.stream.download(output_path=file_dir,
                                              max_retries=10,
                                              filename_prefix=prefix,
                                              )

    def download(self, path, prefix=None):
        """ Download to `path` folder """
        thread = Thread(target=self._download,
                        args=(path, ), kwargs={"prefix": prefix})
        thread.start()

    def register_on_complete(self, func):
        """ `func` is a callable that takes `stream` and `filepath` """
        self.yt_obj.register_on_complete_callback(func)

    def register_on_progress(self, func):
        """ `func` is a callable that takes `stream`, `chunk` and `bytes_remaining` """
        self.yt_obj.register_on_progress_callback(func)


class YTAudio(Base):
    """ Highest quality audio yt_obj """

    def __init__(self, yt: YouTube):
        super().__init__(yt)
        # stream webm(160kbps) or (128kbps)
        self.stream = self.yt_obj.streams.get_audio_only(subtype="webm") or self.yt_obj.streams.get_audio_only()


class YTVideo(Base):
    """ Highest quality video yt_obj """

    def __init__(self, yt: YouTube, itag: int):
        super().__init__(yt)
        # get by itag
        get = self.yt_obj.streams.get_by_itag

        self.stream = get(itag)
        self.audio = YTAudio(yt)

    def _download(self, file_dir, prefix=None):
        """ file_dir: folder to download to """
        try:
            join = os.path.join
            splitext = os.path.splitext
            px = self.stream.resolution
            vidname = self.filename

            if self.stream.is_adaptive:
                print("Downloading audio...")
                # download audio
                self.audio.download(file_dir, prefix="Audio_")

            print("Downloading video...")
            # download video
            super()._download(file_dir, prefix=prefix)
            # when done
            print("Video:", self.file_path)

            if (self.file_path and self.audio.file_path):

                final_filename = join(file_dir, f"{splitext(vidname)[0]}_{px}.mp4")
                print("Audio:", self.audio.file_path)
                # merge
                print("Processing video...")
                self.add_audio(self.file_path, self.audio.file_path, final_filename)
                print("OUTPUT:", final_filename)

        except Exception as e:
            print(e)

    def add_audio(self, src_video, src_audio, output, remove_src=False):
        """ add audio to video using moviepy API """
        start = time.time()
        with VideoFileClip(src_video) as video:
            with AudioFileClip(src_audio) as audio:
                video.audio = audio
                video.write_videofile(output, threads=3, verbose=False, logger=None)

        print("MOVIEPY DONE:", (time.time() - start), "sec")
        if remove_src:
            os.remove(src_video)
            os.remove(src_audio)

    def f_add_audio(self, src_video, src_audio, output, remove_src=False):
        """ add audio to video using ffmpeg directly """
        start = time.time()
        ffmpeg_merge_video_audio(src_video, src_audio, output, vcodec="libx264", acodec="aac", ffmpeg_output=True)
        print("FFMPEG DONE:", (time.time() - start), "sec")

        if remove_src:
            os.remove(src_video)
            os.remove(src_audio)


def get_yt(link: str):
    try:
        return YouTube(link)
    except Exception:
        return


if __name__ == '__main__':
    yt = get_yt("https://youtu.be/gd5CMNZc8JM")
    video = YTVideo(yt, 248)
    audio = YTAudio(yt)
    # video.download(r"C:\Users\Windows 10 Pro\Desktop\Lazy Selector 4.2", prefix="Video_")
    print(video.stream)
    print(audio.stream)
