from tkinter import Frame, Button, Label, Radiobutton, StringVar


class TPopup(Frame):

    def __init__(self, master, vid_streams, aud_streams):

        super().__init__(master)
        self.root = master
        self.root.wm_geometry("300x400")
        self.root.wm_protocol("WM_DELETE_WINDOW", self.okay)

        self.selected_aud = StringVar(master=self.root, value="a")
        self.selected_vid = StringVar(master=self.root, value="v")

        self.pack(fill="both")
        self.create_widgets(vid_streams, aud_streams)

    def create_widgets(self, vid_streams, aud_streams):
        self.video_title = Label(self, text="Video resolutions:", font=("", 11, "underline"))
        self.video_title.pack(side="top", fill="x")

        for stream in vid_streams:
            radiobtn = Radiobutton(self, variable=self.selected_vid, anchor="w",
                                   value=stream, text=stream)
            radiobtn.pack(fill="x")

        self.audio_title = Label(self, text="Audio available:", font=("", 11, "underline"))
        self.audio_title.pack(side="top", fill="x")

        for stream in aud_streams:
            radiobtn = Radiobutton(self, variable=self.selected_aud, anchor="w",
                                   value=stream, text=stream)
            radiobtn.pack(fill="x")

        self.ok = Button(self, text="Download Selected", bg="#ccffa6", command=self.okay)
        self.ok.pack(side="bottom", pady=10)

    def okay(self):
        audio, video = self.selected_aud.get(), self.selected_vid.get()
        self.root.destroy()

        if (len(audio) > 1 and len(video) > 1):
            return (audio, video)


if __name__ == "__main__":
    from tkinter import Tk
    tk = Tk()
    app = TPopup(tk, ["248 1080p", "22 720p"], ["141 160kbps", "171 128kbps"])

    tk.mainloop()
