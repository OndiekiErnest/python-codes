# Arithmetic operators:
# Addition:          3 + 2
# Subtraction:       3 - 2
# Multiplication:    3 * 2
# Division:          3 / 2
# Floor Division:    3 // 2
# Exponent:          3 ** 2
# Modulus/Remainder: 3 % 2

print(3 / 2)

# perform divisibility test
print(3 // 2)

num = 3

num = num + 2
# trick I like using
# num += 2
print(num)

# remove negative sign from numbers using abs() function
print(abs(-7))

# rounding floats using the round() function, the return value is an int
print(round(3.76, 1))

# Comparisons:
# Equal:            3 == 2
# Not Equal:        3 != 2
# Greater Than:     3 > 2
# Less Than:        3 < 2
# Greater or Equal: 3 >= 2
# Less or Equal     3 <= 2

num_1 = 3
num_2 = 2
# returns a boolean type (True or False)
print(num_1 != num_2)
