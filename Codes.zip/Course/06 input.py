
# the input() function waits for the user to type something on the keyboard and press ENTER
# sublime text is not good with inputs, I like using IDLE instead

# get user input and assign it to name variable
# the return value is ALWAYS a str
name = input("Enter your name: ")
print(name)

# you can put your question/prompt in the parenthesis of the input() function
# the prompt is a string
item = input("Item: ")

# to get an int/float, you should cast the return value of input()
size = int(input("Size: "))
cost = float(input("Cost: "))

# f-string
print(f"{item.title()} size {size} costs {cost}.")


prompt = "Enter your weight"

# format the prompt to contain ": "

weight = input(prompt)
print(weight, "KG")
