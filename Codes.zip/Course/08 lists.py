# lists and tuples
# lists and tuples are basically the same but unlike tuples, lists are mutable

# list are very commonly used
# list
alphabets_list = ["c", "a", "e", "b", "d", "f"]
# tuple
alphabets_tuple = ("c", "a", "e", "b", "d", "f")

# printing lists
print(alphabets_list)

# how many items are there in a list?
length = len(alphabets_list)  # returns an int
print(length)

# printing an item of a list using its index
# indexes of lists and tuples start at zero
# accesing an item by its index is faster
print(alphabets_list[0])

# print using negative indexes
# the last item
print(alphabets_list[-1])

# printing an index more than the length of the list will raise an error
print(alphabets_list[10])

# to get an index of an item in list use:
index = alphabets_list.index("d")
# for a tuple too
index = alphabets_tuple.index("d")

# list slicing
print(alphabets_list[0:2])
print(alphabets_list[2:])

# adding an item to the end of the list
alphabets_list.append("g")

# adding many items to the end of the list
alphabets_list.extend(["h", "i", "j"])

# adding an item at a specific index in the list
alphabets_list.insert(0, "k")

# remove an item
alphabets_list.remove("a")

# remove/pop an item at index
# pop returns the removed item, unlike remove
popped_item = alphabets_list.pop(-1)

# reverse a list
alphabets_list.reverse()

# sort
# sorting helps especially in performing efficient searches
alphabets_list.sort(reverse=True)

# if you want to make a copy of sorted alphabets_list
sorted_alphabets_list = sorted(alphabets_list)

# some operations on number sequence
nums = [1, 3, 7, 2, 5, 4, 6]
print(min(nums))
print(max(nums))
print(sum(nums))

# getting the count of an item
occurance = alphabets_list.count("e")
# for tuples too
occurance = alphabets_tuple.count("e")

# checking availability of an item in list/tuple
item_to_check = "a"
print(item_to_check in alphabets_list)
# returns True if item available, otherwise False

# turn list/tuple to a string value (works for a list that contains ONLY str values)
alphabets_str = ", ".join(alphabets_list)

# turn string value to a list
new_alphabets_list = alphabets_str.split(", ")
print(new_alphabets_list)
