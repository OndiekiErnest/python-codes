# variables are names assigned to values in computer memory
# keep variables as descriptive as possible
# observe rules governing vaiables

name = 'Ernesto'
age: int = 3  # int
accountBalance = 15000.47  # float

# types: string (str), integer (int), floating-point number (float)
# statically-typed language: C/C++, Java
# Python is a dynamically-typed language, variables can any type other than the one initialized with
age = "three"  # str
accountBalance = "fifteen thousand"  # str

# Python is case-sensitive, meaning
NAME = "Dan"
# is different from the first name variable

# avoid using variables with single letters, unless you are just playing around
# it's better when variables are describing what they store in memory
d = "22/03/04"
a = 7
# makes no sense later, say in years

# trick I like when declaring variables
# value-unpacking
name, age = "David", 7
# some argue that this method is faster than the ones above
