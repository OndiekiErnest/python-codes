# string operations
string = "Kenya"

multi_line = """Today is Saturday.
It's cloudy.
Seems like it may rain.
"""

# print(multi_line)

# lower-case/small letters
print(string.lower())
# upper-case
print(string.upper())

# get the length of the string using len() function
# this function doesn't work for integers
integer = 4372
print(len(string))
print(len(integer))

# string slicing
# list and string: sequence
name = "David"
# print the first letter of the string
# index starts at zero
print(name[0])
print(name[2:])

# replace words/letters in strings
# you can use this function to replace sensitive words in sentences
new_day = multi_line.replace("Saturday", "Sunday")
print(new_day)

# string formatting
# f-strings/formatted string literals: they are handy in combining variables/functions and strings
# note the curly braces
print(string + "ns")
print(f"{string}ns")

print(f"{name}'s booklet.")

# why I like f-strings
first_name = 12
last_name = "Bob"

# string concatination
# to concatenate an int, you should first cast it to a str as below
full_name = str(first_name) + " " + last_name
# note the SPACE after Prof.
titled_name = "Prof. " + full_name
print(titled_name)
# 1. it's short and straightforward
full_name = f"{first_name} {last_name}"
# 2. has more functionalities and still readable
# you can write codes within the braces
full_name = f"{first_name} {last_name.upper()}"
print(full_name)
