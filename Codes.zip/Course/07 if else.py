# if elif else conditionals: Flow control

# Comparisons:
# Equal:            3 == 2
# Not Equal:        3 != 2
# Greater Than:     3 > 2
# Less Than:        3 < 2
# Greater or Equal: 3 >= 2
# Less or Equal     3 <= 2
# Object Identity:  3 is 2

# 1. Boolean values
condition = True
if condition:
    print("Evaluated to True")
else:
    print("Evaluated to False")


# Comparison
password = "hello"
if password == "hello!1":
    # this is called the if block
    # blocks begin with indentation and may contain other blocks like the code below
    print("Correct password!")
else:
    # else block
    print("Wrong password!")

num_1 = int(input("Enter the first number: "))
num_2 = int(input("Enter the second number: "))

# if num_1 > num_2:
# 	print(num_1, ">", num_2)
# else:
# else block
# 	if num_1 == num_2:
# if block within an else block
# 		print(num_1, "==", num_2)

# elif statements
if num_1 > num_2:
    print(num_1, ">", num_2)
elif num_1 == num_2:
    print(num_1, "==", num_2)
else:
    print(num_2, ">", num_1)

# Values that evaluate to False
# - False
# - None
# - Number 0
# - Empty sequence like "", [], ()
# - Empty mappings like {}

value = False
if value:
    print("Evaluated to True")
else:
    print("Evaluated to False")

# 2. Boolean operators: and, or, not
# combine Boolean values with comparison using Boolean operators
condition = False
password = ""
if condition and password:
    print("Condition met and password provided")
else:  # not condition and not password
    print("Condition not met and password not provided")
