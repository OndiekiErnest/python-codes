# a data type is a category for values, and every value belongs to exactly one data type
# we have strings (str), integers (int), floating-points (float)
# integers are whole numbers
# floats are decimal-point numbers
# strings are textual data in quotes

string = "This is a string data type"
integer = 9
floating_point = 0.1

# check the type of a variable using type() function
print(type(string))

type_ = type(string)
print(type_)
print(type(integer))
print(type(floating_point))

# you can cast/convert between some data types using str(), int() and float() functions
# cast/convert anything to a string
integer_string = str(integer)

print(repr(integer_string))

# cast/convert ONLY integer-containing string to integer
integer = int(integer_string)
print(repr(integer))
# anything else will raise an error like the one below
# integer = int("Bob1")
# the . is not a point anymore, it's a fullstop in this case
# integer = int("99.9")

# you can cast/convert between numeric data without errors
float_point = 4.9
integer = 5

floating_point = float(integer)
print(float_point, "\t", integer)
print(int(8 / 2))  # division always results to a float type

"""
	QUESTION: Write a program that will show how many hours, minutes, and seconds are there in 5 days
"""
number_of_days = 5
hours = number_of_days * 24
minutes = hours * 60
seconds = minutes * 60

print(number_of_days, "\t", hours, "\t", minutes, "\t", seconds)
