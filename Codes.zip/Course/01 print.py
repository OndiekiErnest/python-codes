# this is a comment, it's never executed in Python. Used as notes or reminders, or to avoid running a certain line of code.
# print a welcome message to the user
# comments can also be trailing the line they describe, but it's discouraged
print("Hello there, welcome to my first program.")

# print a line with an apostrophe
print("Dan's dog.")
# use escape character
print('Dan\'s dog.')
print('Dan said, "Hello."')
# or
# print("Dan's dog.")

# print a statement with a newline
print("Hello! How are you today?")
print("Hello!\n\n\nHow are you today?")

# print a line with a tab
print("Consider the following:\n\t1. Gender\t2. Age")
print("\t1. Gender\t2. Age\t3. Name")
print("\t1. Gender\t2. Age")


# print math expressions, the spaces are for readability
print(2 + 3)
print((16 - 4) + 6)
