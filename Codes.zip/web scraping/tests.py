# import
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


def test_eight_components():
    # start session
    driver = webdriver.Chrome()

    # navigate to url
    driver.get("https://google.com")

    # request info
    title = driver.title
    # ascertain
    print("TITLE:", title)

    # driver.implicitly_wait(0.5)

    # find elements
    search_box = driver.find_element(by=By.NAME, value="q")

    # simulate actions; type and then enter
    search_box.send_keys(f"Selenium {Keys.ENTER}")

    # ascertain
    search_box = driver.find_element(by=By.NAME, value="q")
    value = search_box.get_attribute("value")
    print("SEARCH BOX VALUE:", value)

    # close session
    driver.quit()


if __name__ == "__main__":
    test_eight_components()
