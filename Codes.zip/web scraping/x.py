# import
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
import csv


def exists_by_xpath(driver, xpath):
    try:
        driver.find_element(By.XPATH, xpath)
    except NoSuchElementException:
        return False
    return True


def search_x(txt: str):
    """ """
    URL = "https://www.xvideos.com"
    with open("fetched.csv", "w") as FILE:
        CSV_WRITER = csv.writer(FILE)
        driver = webdriver.Chrome()
        # wait at most, before raising NoSuchElement exception
        driver.implicitly_wait(15)
        driver.get(URL)

        search_input = driver.find_element(By.XPATH, '//*[@id="xv-search-form"]/div/div/input')
        search_input.send_keys(f"{txt}{Keys.ENTER}")

        fetched = driver.find_element(By.XPATH, '//*[@id="main"]/h2/span').text

        limit = 1
        while exists_by_xpath(driver, '//*[@id="content"]/div[2]/ul/li[20]/a/span[1]'):
            content_element = driver.find_element(By.XPATH, '//*[@id="content"]')

            for element in content_element.find_elements(By.CLASS_NAME, 'thumb-block'):
                # get unique id
                element_id = element.get_attribute("id")
                # split id based on underscore
                group, data_id = element_id.split("_")
                # thumb image
                thumbnail_link = element.find_element(By.XPATH, f'//*[@id="pic_{data_id}"]').get_attribute("src")
                # title div under the thumb image
                title_element = element.find_element(By.XPATH, f'//*[@id="{element_id}"]/div[2]/p[1]/a')
                # title
                title = title_element.text
                # video_link
                video_link = title_element.get_attribute("href")
                CSV_WRITER.writerow((title, video_link, thumbnail_link))
                # print(video_link)

            # go to the next page
            content_element.find_element(By.XPATH, '//*[@id="content"]/div[2]/ul/li[20]/a/span[1]').click()
            limit -= 1
            if limit < 1:
                break

        driver.quit()
        return fetched


if __name__ == "__main__":
    results = search_x("homemade")
    print(">>>", results)
