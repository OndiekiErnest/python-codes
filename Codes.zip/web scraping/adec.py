from requests import get
from plyer import notification
from bs4 import BeautifulSoup

URL = "https://www.adec-innovations.com/resources/#news"
try:
    page = get(URL)

    soup = BeautifulSoup(page.content, "html.parser")
    results = soup.find("div", class_="careers-grid-container")

    results_len = len(results)
    msg = "No jobs to display."
    if results_len > 3:
        msg = f"There may be jobs. Got {results_len} results"

    notification.notify(title="ADEC-KENYA Jobs", message=msg)
except Exception as e:
    notification.notify(title="ERROR making requests", message=str(e)[:256])
