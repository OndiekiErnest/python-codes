import sys
from functools import cached_property
from PyQt5.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest

from PyQt5.QtCore import pyqtSlot, Qt, QUrl, pyqtSignal, QObject
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtWidgets import (
    QApplication,
    QComboBox,
    QLabel,
    QMainWindow,
    QVBoxLayout,
    QWidget,
    QLineEdit,
    QPushButton,
    QGridLayout,
)


class NetMainWindow(QMainWindow):
    def __init__(self, parent=None):
        super(NetMainWindow, self).__init__(parent)
        self.setWindowTitle("Pics")

        self.manager = QNetworkAccessManager()
        self.manager.finished.connect(self.on_finished)

        self.widgetIMG = QLabel(alignment=Qt.AlignHCenter)

        self.widgetList = QComboBox()
        self.widgetList.currentIndexChanged.connect(self.display)
        for text, url in zip(
            ("first image", "second image", "third image"),
            (
                "https://cdn77-pic.xvideos-cdn.com/videos_new/thumbs169ll/b7/cb/3c/b7cb3c7c7ce892a6c9838a1b73200a44-1/b7cb3c7c7ce892a6c9838a1b73200a44.6.jpg",
                "https://cdn77-pic.xvideos-cdn.com/videos_new/thumbs169ll/b7/cb/3c/b7cb3c7c7ce892a6c9838a1b73200a44-1/b7cb3c7c7ce892a6c9838a1b73200a44.6.jpg",
                "https://cdn77-pic.xvideos-cdn.com/videos_new/thumbs169ll/b7/cb/3c/b7cb3c7c7ce892a6c9838a1b73200a44-1/b7cb3c7c7ce892a6c9838a1b73200a44.6.jpg",
            ),
        ):
            self.widgetList.addItem(text, url)

        widget = QWidget()
        lo2 = QVBoxLayout(widget)
        lo2.addWidget(self.widgetIMG)
        lo2.addWidget(self.widgetList)
        self.setCentralWidget(widget)

    @pyqtSlot(int)
    def display(self, ix):
        url = self.widgetList.itemData(ix)
        self.start_request(url)

    def start_request(self, url):
        request = QNetworkRequest(QUrl(url))
        self.manager.get(request)

    @pyqtSlot(QNetworkReply)
    def on_finished(self, reply):
        target = reply.attribute(QNetworkRequest.RedirectionTargetAttribute)
        if reply.error():
            print("error: {}".format(reply.errorString()))
            return
        elif target:
            newUrl = reply.url().resolved(target)
            self.start_request(newUrl)
            return
        pixmap = QPixmap()
        pixmap.loadFromData(reply.readAll())
        self.widgetIMG.setPixmap(pixmap.scaledToHeight(480))


class ImageDownloader(QObject):
    finished = pyqtSignal(QImage)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.manager.finished.connect(self.handle_finished)

    @cached_property
    def manager(self):
        return QNetworkAccessManager()

    def start_download(self, url):
        self.manager.get(QNetworkRequest(url))

    def handle_finished(self, reply):
        if reply.error() != QNetworkReply.NoError:
            print("error: ", reply.errorString())
            return
        image = QImage()
        image.loadFromData(reply.readAll())
        self.finished.emit(image)


class Widget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.lineedit = QLineEdit()
        self.button = QPushButton("Start")
        self.label = QLabel(alignment=Qt.AlignCenter)

        lay = QGridLayout(self)
        lay.addWidget(self.lineedit, 0, 0)
        lay.addWidget(self.button, 0, 1)
        lay.addWidget(self.label, 1, 0, 1, 2)

        self.downloader = ImageDownloader()

        self.downloader.finished.connect(self.handle_finished)
        self.button.clicked.connect(self.handle_clicked)

        self.lineedit.setText("http://openweathermap.org/img/wn/01d@2x.png")

        self.resize(640, 480)

    def handle_finished(self, image):
        pixmap = QPixmap.fromImage(image)
        self.label.setPixmap(pixmap)

    def handle_clicked(self):
        url = QUrl.fromUserInput(self.lineedit.text())
        self.downloader.start_download(url)


def main():
    app = QApplication(sys.argv)
    w = Widget()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

# if __name__ == "__main__":

#     app = QApplication(sys.argv)
#     window = NetMainWindow()
#     window.show()
#     sys.exit(app.exec_())
