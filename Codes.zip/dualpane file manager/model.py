""" data model prepares data for presentation """

from PyQt5.QtWidgets import QFileSystemModel
