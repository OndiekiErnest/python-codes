from moviepy.editor import VideoFileClip
from os.path import abspath, dirname, splitext, join, isfile, isdir, exists

base_dir = dirname(abspath(__file__))


def res(filename: str, height: int, output=None):
    """
    resize video filename to `height` (width is computed automatically)
    `output` is a file path
    """
    # take care of file refs
    cwd = dirname(filename) or base_dir
    name, ext = splitext(filename)
    new_name = f"{name}({height}P){ext}"

    if output is None:
        output = join(cwd, new_name)
    elif isfile(output) and exists(output):
        print("Warning: `output` already exists.")
        output = join(dirname(output), new_name)
    elif isdir(output):
        output = join(output, new_name)

    # get the video
    try:
        print("Output:", output)
        clip = VideoFileClip(filename)
        resized = clip.resize(height=height)
        resized.write_videofile(output)
    except Exception as e:
        print(e)


if __name__ == '__main__':
    res(r"D:\Video\LATEST POP HITS VIDEO MIX 2021 _ DJ BASHFUL [SHAWN MENDES, TAYLOR SWIFT, ED SHEERAN, KHALID].mp4", 480)
