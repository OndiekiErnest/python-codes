from decimal import Decimal
import re
from borb.pdf import PDF
from borb.pdf.canvas.geometry.rectangle import Rectangle
from borb.toolkit.location.location_filter import LocationFilter
from borb.toolkit.text.simple_text_extraction import SimpleTextExtraction
from borb.toolkit.text.regular_expression_text_extraction import RegularExpressionTextExtraction
from io import StringIO

from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfparser import PDFParser

FILE = "C:\\Users\\Windows 10 Pro\\Desktop\\Codes\\Donny\\extractor\\Invoice.pdf"

output_string = StringIO()
with open(FILE, 'rb') as in_file:
    parser = PDFParser(in_file)
    doc = PDFDocument(parser)
    rsrcmgr = PDFResourceManager()
    device = TextConverter(rsrcmgr, output_string, laparams=LAParams())
    interpreter = PDFPageInterpreter(rsrcmgr, device)
    for page in PDFPage.create_pages(doc):
        interpreter.process_page(page)

print(output_string.getvalue())


def find_ship_to() -> Rectangle:

    document = None

    # Set up EventListener
    text_extractor = RegularExpressionTextExtraction("Shipping Address")
    with open(FILE, "rb") as pdf_in_handle:
        document = PDF.loads(pdf_in_handle, [text_extractor])

    assert document is not None

    matches = text_extractor.get_matches_for_page(0)
    print(len(matches))

    return matches[0].get_bounding_boxes()[0]


def main():

    document = None

    # Define rectangle of interest
    ship_to_rectangle = find_ship_to()
    shippig_rect = Rectangle(ship_to_rectangle.get_x() - Decimal(50),
                             ship_to_rectangle.get_y() - Decimal(100),
                             Decimal(200),
                             Decimal(130))

    # Set up EventListener(s)
    text_location = LocationFilter(shippig_rect)
    text_extractor = SimpleTextExtraction()
    text_location.add_listener(text_extractor)

    with open(FILE, "rb") as pdf_in_handle:
        document = PDF.loads(pdf_in_handle, [text_location])

    assert document is not None
    print(text_extractor.get_text_for_page(0))


# if __name__ == "__main__":
#     main()
