import time

print(time.time())

print("Classic!")
