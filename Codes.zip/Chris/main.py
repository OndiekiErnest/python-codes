from PyQt5.QtWidgets import (
    QApplication, QWidget,
    QProgressBar, QLabel,
    QLineEdit, QPushButton,
    QMainWindow, QGroupBox,
    QHBoxLayout, QFrame,
    QVBoxLayout, QGridLayout,
    QFormLayout, QRadioButton,
)

import sys
from random import randint
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import Qt, QTimer
from os.path import abspath, dirname, join

# custom widget styles, qss
style = """
QWidget {
    font: 20px;
    font-family: Consolas, Helvetica;
}
QMainWindow#main {
    background-color: #05042b;
}
QWidget#stats, QLabel {
    background: #111c2e;
    color: white;
}
QLabel#results {
    background-color: #05042b;
}
QLineEdit {
    background-color: #1f2736;
    color: white;
    border: 0px;
    border-radius: 2px;
}
QLineEdit:focus {
    border: 1px solid #6ce5e8;
}
.QPushButton {
    background-color: #111c2e;
    border: 2px solid gray;
    color: white;
    border-radius: 5px;
    padding: 5px;
}
.QPushButton:hover {
    border: 2px solid #6ce5e8;
    border-radius: 5px;
}
.QPushButton:enabled {
    color: white;
}
.QPushButton:disabled {
    color: gray;
}
.QPushButton:pressed {
    background-color: #144ca6;
}
QGroupBox {
    border: 2px solid gray;
    border-radius: 5px;
    margin-top: 4ex;
    color: white;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top center;
}
QRadioButton {
    color: white;
}
"""

# folder of this source file
BASE_DIR = dirname(abspath(__file__))


def r_path(relpath):
    """
    Get absolute path even for compiled apps
    """

    base_path = getattr(sys, "_MEIPASS", BASE_DIR)
    return join(base_path, relpath)


# data folder
DATA_DIR = r_path("data")


class LineEdit(QFrame):
    """ custom widget, label and input box combination in one line """

    def __init__(self, txt, *args, **kwargs):
        super().__init__(*args, **kwargs)

        mainL = QHBoxLayout(self)
        mainL.setContentsMargins(0, 0, 0, 0)

        self.edit = QLineEdit()
        self.edit.setFixedWidth(150)

        mainL.addWidget(QLabel(txt))
        mainL.addWidget(self.edit)


class Edit(QLineEdit):
    """ custom input box with fixed width """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.setFixedWidth(120)
        # self.setReadOnly(True)


class Player(QWidget):
    """ Player stats input window """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setObjectName("stats")

        self.setFixedSize(720, 720)
        self.setWindowTitle("Player stats")

        self._create_widgets()

    def _create_widgets(self):
        """ create player widgets """

        mainlayout = QVBoxLayout()  # layouts
        year_layout = QHBoxLayout()
        stats_layout = QGridLayout()
        stats_layout.setHorizontalSpacing(20)

        charcts_group = QGroupBox("Characteristics")

        stats_group = QGroupBox("Stats")
        stats_group.setLayout(stats_layout)

        mainlayout.addLayout(year_layout)
        mainlayout.addWidget(charcts_group)
        mainlayout.addWidget(stats_group)

        year_layout.addWidget(QLabel("Year"))

        years = ("1", "2", "3", "4", "5", "6")
        for year in years:
            ybtn = QPushButton(year)
            ybtn.clicked.connect(self.clear_everything)  # clear input boxes this button is clicked
            year_layout.addWidget(ybtn)

        toplayout = QFormLayout()

        charcts_group.setLayout(toplayout)

        self.setLayout(mainlayout)

        self.age = QLineEdit()
        self.age.setFixedWidth(300)

        self.height = QLineEdit()
        self.height.setFixedWidth(300)

        self.weight = QLineEdit()
        self.weight.setFixedWidth(300)

        self.ok = QPushButton("OK")
        self.ok.setIcon(QIcon(f"{DATA_DIR}\\tick.png"))

        toplayout.addRow("Age:", self.age)
        toplayout.addRow("Height:", self.height)
        toplayout.addRow("Weight:", self.weight)
        # add widgets in a loop
        stats = ("Pos :", "Tm :", "G :", "GS :", "MP :",
                 "FG :", "FGA :", "FG% :", "3P :", "3PA :", "3P% :",
                 "2P :", "2PA :", "2P% :", "eFG% :", "FT :", "FTA :",
                 "FT% :", "ORB :", "DRB :", "TRB :", "AST :", "STL :",
                 "BLK :", "TOV :", "PF :", "PTS :",
                 )
        self.edits = []
        row, col = 0, 0
        data_len = len(stats)
        col_size = 2
        for r in range(data_len):
            try:
                lineedit = LineEdit(stats[r])
                stats_layout.addWidget(lineedit, row, col)
                self.edits.append(lineedit.edit)
                col += 1
                if col == col_size:
                    row, col = row + 1, 0
            except IndexError:
                break

        mainlayout.addWidget(self.ok, alignment=Qt.AlignRight)

    def clear_everything(self):
        """ clear every QLineEdit """
        self.edits.extend((self.age, self.height, self.weight))
        for edit in self.edits:
            edit.clear()


class Home(QWidget):
    """ Players and other btns """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setObjectName("home")

        self.timer = QTimer()
        self.timer.setInterval(400)
        self.timer.timeout.connect(self.move)
        self.progress_value = 0

        self.popup = Player()
        self.popup.ok.clicked.connect(self.okay_clicked)
        self.popup.setWindowModality(Qt.ApplicationModal)
        self.popup.setWindowIcon(self.windowIcon())

        self._create_widgets()

    def _create_widgets(self):
        """ create home widgets, map them to window """

        main_layout = QGridLayout()

        player_btns_layout = QGridLayout()
        player_btns_layout.setVerticalSpacing(10)
        player_btns_layout.setHorizontalSpacing(10)
        player_btns_layout.setAlignment(Qt.AlignRight)
        main_layout.addLayout(player_btns_layout, 0, 0)

        calc_layout = QVBoxLayout()
        calc_layout.setSpacing(20)
        main_layout.addLayout(calc_layout, 1, 3)

        self.setLayout(main_layout)

        self.player1 = QPushButton("Player 1")
        self.player1.setFixedSize(105, 40)
        self.player1.clicked.connect(self.popup.show)  # open popup when player clicked
        self.player2 = QPushButton("Player 2")
        self.player2.clicked.connect(self.popup.show)
        self.player3 = QPushButton("Player 3")
        self.player3.clicked.connect(self.popup.show)

        self.player_calc = QPushButton("Calculate")
        self.player_calc.setIcon(QIcon(f"{DATA_DIR}\\tick.png"))

        clear = QPushButton("Clear All")

        self.progress = QProgressBar()
        self.progress.setTextVisible(True)
        self.progress.setAlignment(Qt.AlignCenter)
        self.progress.setRange(0, 100)
        # hide it on startup
        self.progress.hide()

        rand_1 = f"{randint(100, 999)}"
        rand_2 = f"{randint(100, 999)}"
        rand_3 = f"{randint(100, 999)}"

        enume = QRadioButton("Enumerate")
        enume.setChecked(True)

        title = QLabel("Results")
        title.setObjectName("results")
        title.setFixedSize(120, 30)

        player_btns_layout.addWidget(title, 0, 1)
        player_btns_layout.addWidget(self.player1, 1, 0)
        player_btns_layout.addWidget(Edit(rand_1), 1, 1)
        player_btns_layout.addWidget(self.player2, 2, 0)
        player_btns_layout.addWidget(Edit(rand_2), 2, 1)
        player_btns_layout.addWidget(self.player3, 3, 0)
        player_btns_layout.addWidget(Edit(rand_3), 3, 1)
        calc_layout.addWidget(self.player_calc)
        calc_layout.addWidget(clear)
        calc_layout.addWidget(enume)
        calc_layout.addWidget(QRadioButton("Monte Carlo"))
        main_layout.addWidget(self.progress, 3, 0, 1, -1)

    def move(self):
        """ update progress bar every half a sec """
        self.progress_value += randint(1, 2)
        if self.progress_value > 100:
            self.progress_value = 100
            self.timer.stop()
        self.progress.setValue(self.progress_value)

    def okay_clicked(self):
        """ hide popup """
        self.popup.hide()


class Main(QMainWindow):
    """ main application window """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setObjectName("main")

        self.setWindowTitle("Player Selector")
        self.setWindowIcon(QIcon(f"{DATA_DIR}\\icon.png"))

        self._create_widgets()
        self._create_menu()

    def _create_widgets(self):
        """ create main window widgets """
        self.widget = Home(self)
        self.widget.player_calc.clicked.connect(self.calc_clicked)
        self.setCentralWidget(self.widget)

    def _create_menu(self):
        menu = self.menuBar()
        menu.addAction("&File")
        menu.addAction("&Edit")
        menu.addAction("&Analysis")
        menu.addAction("&Train")
        menu.addAction("&Help")
        self.setMenuBar(menu)

    def calc_clicked(self):
        """ start progress bar when `Calculate` clicked """
        self.widget.timer.stop()
        # restart from 0 if the progress bar has ended or is running
        self.widget.progress_value = 0
        self.widget.progress.show()
        self.widget.timer.start()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    # set the style application-wide
    app.setStyleSheet(style)

    win = Main()
    win.showMaximized()

    sys.exit(app.exec())
