import os
# from re import sub
from typing import Iterable


def _rename(old: str, new: str):
    """ rename file, handle exceptions """
    # old, new = old.strip(), new.strip()
    # replace the characters in [] in title, because filenames can't contain them
    # save_title = sub(r'[:\\/"*?|<>]', "-", new)
    try:
        os.rename(old, new)
        print(">>> renamed:", new)

    except Exception as e:
        print(f"Error renaming '{old}':", e)


def strip_rename(txts: Iterable[str], src_path: str):
    """ strip unwanted txt from path then rename """
    file_dir, name_ext = os.path.dirname(src_path), os.path.basename(src_path)
    # split extension
    name, ext = os.path.splitext(name_ext)

    for txt in txts:
        if txt in name:
            # strip text
            new_name = name.strip(txt)
            new_filename = os.path.join(file_dir, f"{new_name}{ext}")
            # rename
            _rename(src_path, new_filename)


def rename_in_dir(path: str, rename_strs: Iterable[str]):
    """ loop through files trying to rename each """
    join = os.path.join
    for root, sub_dir, files in os.walk(path):
        for file in files:
            strip_rename(rename_strs, join(root, file))


if __name__ == '__main__':
    rename_in_dir(r"C:\Users\Windows 10 Pro\Music",
                  {"abdwap - ", "9convert.com - ", "(Tubidy.io)", "y2mate.com - "}
                  )
