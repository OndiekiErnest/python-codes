# implementation of zero-copy algo for file transfer

def zero_copy(fsrc, fdst, length=1048576, callback=None):
    """
    readinto()/memoryview()-based variant of copyfileobj()
    *fsrc* must support readinto() method and both files must be
    open in binary mode.

    Example:
    with open("src_path", "rb") as fsrc:
        with open("dst_path", "wb") as fdst:
            zero_copy(fsrc, fdst)
    """
    # localize variable access to minimize overhead
    fsrc_readinto = fsrc.readinto
    fdst_write = fdst.write
    with memoryview(bytearray(length)) as mv:

        while 1:
            n = fsrc_readinto(mv)
            if not n:
                break

            elif n < length:
                with mv[:n] as smv:
                    fdst.write(smv)
            else:
                fdst_write(mv)
