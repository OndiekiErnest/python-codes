from django.shortcuts import render
from django.http import HttpResponseRedirect
from .models import ToDoList
from .forms import CreateNewList

# Create your views here.


def index(response):
    """ render home view """
    return render(response, "main/home.html", {})


def get(response, list_id: int):
    """ query the database using id while accepting edits """
    lst = ToDoList.objects.get(id=list_id)

    if lst in response.user.todolist.all():
        # print("query RESPONSE:", response.POST)
        if response.method == "POST":
            if response.POST.get("save"):
                for item in lst.item_set.all():
                    if response.POST.get(f"c{item.id}") == "clicked":
                        item.complete = True
                    else:
                        item.complete = False
                    item.save()
            elif response.POST.get("newItem"):
                txt = response.POST.get("new")
                if len(txt) > 3:
                    lst.item_set.create(text=txt, complete=False)
                else:
                    print("INVALID ITEM!")

        return render(response, "main/query.html", {"ls": lst})

    return render(response, "main/todolists.html", {})


def create(response):
    """ create new todo list and save it to the database, then redirect """
    # print("create RESPONSE:", response.POST)
    if response.method == "POST":
        form = CreateNewList(response.POST)

        if form.is_valid():
            n = form.cleaned_data["name"]
            t = ToDoList(name=n)
            t.save()
            response.user.todolist.add(t)

        return HttpResponseRedirect(f"/{t.id}")

    else:
        form = CreateNewList()
    return render(response, "main/create.html", {"form": form})


def todolists(response):
    return render(response, "main/todolists.html", {})
